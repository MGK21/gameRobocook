let canvas = document.getElementById("main_canvas");
let ctx = canvas.getContext("2d");

export {
    canvas,
    ctx
};