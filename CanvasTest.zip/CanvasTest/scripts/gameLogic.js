const gameLogic = {
    scrollSpeed : 1000,
    defaultScrollSpeed: 1000
}

export {gameLogic};